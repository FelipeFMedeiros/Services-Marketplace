<script lang="ts">
	import { Home, Briefcase, User, Search } from 'lucide-svelte';
</script>

<div class="min-h-screen flex flex-col">
	<!-- Hero Section -->
	<div class="bg-gradient-to-r from-primary-600 to-primary-800 text-white">
		<div class="container mx-auto px-4 py-16">
			<div class="max-w-3xl mx-auto text-center">
				<h1 class="text-4xl md:text-6xl font-bold mb-6">
					Encontre o Profissional Ideal
				</h1>
				<p class="text-xl mb-8 text-primary-100">
					Conectamos você aos melhores prestadores de serviços da sua região
				</p>
				<div class="flex gap-4 justify-center">
					<a href="/services" class="btn bg-white text-primary-600 hover:bg-gray-100">
						<Search class="w-5 h-5 mr-2 inline" />
						Buscar Serviços
					</a>
					<a href="/auth/register" class="btn border-2 border-white text-white hover:bg-primary-700">
						Cadastrar-se
					</a>
				</div>
			</div>
		</div>
	</div>

	<!-- Features -->
	<div class="container mx-auto px-4 py-16">
		<div class="grid md:grid-cols-3 gap-8">
			<div class="card text-center">
				<div class="flex justify-center mb-4">
					<div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
						<Search class="w-8 h-8 text-primary-600" />
					</div>
				</div>
				<h3 class="text-xl font-bold mb-2">Busca Fácil</h3>
				<p class="text-gray-600">
					Encontre profissionais por categoria, localização e avaliações
				</p>
			</div>

			<div class="card text-center">
				<div class="flex justify-center mb-4">
					<div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
						<Briefcase class="w-8 h-8 text-primary-600" />
					</div>
				</div>
				<h3 class="text-xl font-bold mb-2">Agendamento Simples</h3>
				<p class="text-gray-600">
					Escolha data, horário e confirme em poucos cliques
				</p>
			</div>

			<div class="card text-center">
				<div class="flex justify-center mb-4">
					<div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
						<User class="w-8 h-8 text-primary-600" />
					</div>
				</div>
				<h3 class="text-xl font-bold mb-2">Profissionais Verificados</h3>
				<p class="text-gray-600">
					Todos os prestadores são avaliados pela comunidade
				</p>
			</div>
		</div>
	</div>

	<!-- CTA Section -->
	<div class="bg-gray-100 py-16">
		<div class="container mx-auto px-4 text-center">
			<h2 class="text-3xl font-bold mb-4">Você é um Prestador de Serviços?</h2>
			<p class="text-gray-600 mb-8 max-w-2xl mx-auto">
				Cadastre-se gratuitamente e comece a receber contratações hoje mesmo!
			</p>
			<a href="/auth/register?role=provider" class="btn-primary text-lg px-8 py-3">
				Quero Ofertar Meus Serviços
			</a>
		</div>
	</div>
</div>
