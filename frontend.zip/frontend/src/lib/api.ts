import axios from 'axios';

// Configuração base do Axios
export const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  withCredentials: true, // Importante para cookies de autenticação
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para tratamento de erros
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Redirecionar para login se não autenticado
      if (typeof window !== 'undefined') {
        window.location.href = '/auth/login';
      }
    }
    return Promise.reject(error);
  }
);

// Tipos de resposta da API
export interface ApiResponse<T = any> {
  success?: boolean;
  message?: string;
  data?: T;
  error?: string;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

// Auth API
export const authApi = {
  register: (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'CLIENT' | 'PROVIDER';
    city?: string;
    state?: string;
  }) => api.post('/auth/register', data),

  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),

  logout: () => api.post('/auth/logout'),

  me: () => api.get('/auth/me'),
};

// Service Types API
export const serviceTypesApi = {
  getAll: () => api.get('/service-types'),
  getById: (id: number) => api.get(`/service-types/${id}`),
};

// Services API
export const servicesApi = {
  getAll: (params?: {
    serviceTypeId?: number;
    city?: string;
    state?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sortBy?: string;
    page?: number;
    limit?: number;
  }) => api.get('/services', { params }),

  getById: (id: number) => api.get(`/services/${id}`),

  getMy: (params?: { active?: boolean }) => api.get('/services/my', { params }),

  create: (data: {
    name: string;
    description: string;
    serviceTypeId: number;
    allowsMultipleDays?: boolean;
  }) => api.post('/services', data),

  update: (
    id: number,
    data: {
      name?: string;
      description?: string;
      serviceTypeId?: number;
      allowsMultipleDays?: boolean;
      isActive?: boolean;
    }
  ) => api.put(`/services/${id}`, data),

  delete: (id: number) => api.delete(`/services/${id}`),

  // Variations
  createVariation: (
    serviceId: number,
    data: {
      name: string;
      price: number;
      durationMinutes: number;
    }
  ) => api.post(`/services/${serviceId}/variations`, data),

  updateVariation: (
    serviceId: number,
    variationId: number,
    data: {
      name?: string;
      price?: number;
      durationMinutes?: number;
      isActive?: boolean;
    }
  ) => api.put(`/services/${serviceId}/variations/${variationId}`, data),

  deleteVariation: (serviceId: number, variationId: number) =>
    api.delete(`/services/${serviceId}/variations/${variationId}`),

  // Photos
  uploadPhoto: (serviceId: number, file: File) => {
    const formData = new FormData();
    formData.append('photo', file);
    return api.post(`/services/${serviceId}/photos`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  setCoverPhoto: (serviceId: number, photoId: number) =>
    api.put(`/services/${serviceId}/photos/${photoId}/cover`),

  deletePhoto: (serviceId: number, photoId: number) =>
    api.delete(`/services/${serviceId}/photos/${photoId}`),
};

// Providers API
export const providersApi = {
  search: (params?: {
    city?: string;
    state?: string;
    serviceTypeId?: number;
    search?: string;
    sortBy?: string;
    page?: number;
    limit?: number;
  }) => api.get('/providers/search', { params }),

  getById: (id: number) => api.get(`/providers/${id}`),

  updateProfile: (data: {
    bio?: string;
    document?: string;
    city?: string;
    state?: string;
  }) => api.put('/providers/profile', data),

  // Availabilities
  createAvailability: (data: {
    startDatetime: string;
    endDatetime: string;
  }) => api.post('/providers/availabilities', data),

  getMyAvailabilities: (params?: {
    active?: boolean;
    startDate?: string;
    endDate?: string;
  }) => api.get('/providers/availabilities', { params }),

  updateAvailability: (
    id: number,
    data: {
      startDatetime?: string;
      endDatetime?: string;
      isActive?: boolean;
    }
  ) => api.put(`/providers/availabilities/${id}`, data),

  deleteAvailability: (id: number) =>
    api.delete(`/providers/availabilities/${id}`),

  getAvailableSlots: (
    providerId: number,
    params: {
      startDate: string;
      endDate: string;
      durationMinutes?: number;
    }
  ) => api.get(`/providers/${providerId}/available-slots`, { params }),

  // Dashboard
  getBookings: (params?: {
    status?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
  }) => api.get('/providers/bookings', { params }),

  cancelBooking: (id: number, reason?: string) =>
    api.patch(`/providers/bookings/${id}/cancel`, { reason }),

  getStats: () => api.get('/providers/dashboard/stats'),

  getNotifications: (params?: {
    isRead?: boolean;
    page?: number;
    limit?: number;
  }) => api.get('/providers/notifications', { params }),

  markNotificationAsRead: (id: number) =>
    api.patch(`/providers/notifications/${id}/read`),
};

// Bookings API
export const bookingsApi = {
  create: (data: {
    serviceId: number;
    variationId: number;
    startDatetime: string;
  }) => api.post('/bookings', data),

  getMy: (params?: {
    status?: string;
    startDate?: string;
    endDate?: string;
  }) => api.get('/bookings/my', { params }),

  getById: (id: number) => api.get(`/bookings/${id}`),

  cancel: (id: number, reason?: string) =>
    api.patch(`/bookings/${id}/cancel`, { reason }),
};

// Reviews API
export const reviewsApi = {
  create: (data: {
    bookingId: number;
    rating: number;
    comment?: string;
  }) => api.post('/reviews', data),

  getMy: (params?: { page?: number; limit?: number }) =>
    api.get('/reviews/my', { params }),

  getServiceReviews: (
    serviceId: number,
    params?: {
      page?: number;
      limit?: number;
      minRating?: number;
      maxRating?: number;
    }
  ) => api.get(`/reviews/service/${serviceId}`, { params }),

  getById: (id: number) => api.get(`/reviews/${id}`),

  update: (id: number, data: { rating?: number; comment?: string }) =>
    api.put(`/reviews/${id}`, data),

  delete: (id: number) => api.delete(`/reviews/${id}`),
};
